#!/bin/bash -l

python -m memory_profile ./primes_lprof.py --n 1000 --quiet
