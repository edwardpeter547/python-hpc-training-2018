#!/bin/bash -l

kernprof -l -v ./primes_lprof.py --n 1000 --quiet
