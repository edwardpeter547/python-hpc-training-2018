#!/bin/bash -l

cython --annotate quad.pyx
