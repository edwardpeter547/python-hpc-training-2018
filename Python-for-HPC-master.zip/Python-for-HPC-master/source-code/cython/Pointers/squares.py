#!/usr/bin/env python

import pointers


print(pointers.squares(5))
