# Pyspark

Some Pyspark sample code.


##  What is it?

  1. `pyspark.ipynb`: Jupyter notebook illustrating some Pyspark
    functionality running on a local instance.
  1. `config.sh`: example shell script that can be sourced to allow
    running a local spark instance.  Not required when pyspark has been
    installed using conda.
  1. `Data`: data files required for the example code.
