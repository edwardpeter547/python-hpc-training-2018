# Performance

These are some resources about general performance considerations.


## What is it?

1. `number_puzzle.ipynb`: jupyter notebbook solving a number puzzle
   in a variety of ways, shwoing some aspects of performance
   optimization.
