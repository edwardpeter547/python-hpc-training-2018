# File formats

The choice of file format can greatly influcnce I/O performance.


## What is it?

1. `pandas_io.ipynb`: pandas dataframes can be stored in various formats, here
   CSV, parquet and feathers are compared for I/O bandwidth and size.
