#ifndef LOGISTIC_MAP_HDR
#define LOGISTIC_MAP_HDR

double logistic_map(double x, double r, int steps);

#endif

