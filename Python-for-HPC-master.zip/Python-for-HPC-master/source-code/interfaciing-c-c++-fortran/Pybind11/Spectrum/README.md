# Spectrum

Illustration of how to wrap a C++ class so that it support the  buffer protocal.

## What is it?

1. `spectrum.h`: C++ class representing a "spectrum".
1. `spectrum.cpp`: implementation of class methods and pybind11 bindings.
1. `Makefile`: make file to build the Python extension.
1. `spectrum.py`: Python script illustration how to use the C++ object.
