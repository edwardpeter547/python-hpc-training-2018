# Pybind11

pybind11 is a wrapper generator for C++ code that has a lot of nice features.

## What is it?

1. `Spectrum`: illustration of warpping to support the buffer protocol.
1. `Stats`: illustration of wrapping a C++ class.
1. `pybind11.yml`: conda environment specification for this directory.
