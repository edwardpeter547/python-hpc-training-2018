# Pypy

Pypy is an alternative interpreter that can in some circumtatnces be
up to four times faster than CPython.


## What is it?

1. `julia_set.py`: compute the Julia set.


## How to use?

To run with Pypy, use:
```bash
$ pypy julia_set.py 1000 > julia.txt
```
